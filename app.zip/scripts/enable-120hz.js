const fs = require('fs');
const path = require('path');

const mainActivityPath = path.join(
  __dirname,
  '..',
  'android',
  'app',
  'src',
  'main',
  'java',
  'com',
  'olmaths',
  'amaster',
  'MainActivity.java'
);

const mainActivityCode = `package com.olmaths.amaster;

import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enableHighRefreshRate();
    }

    @SuppressWarnings("deprecation")
    private void enableHighRefreshRate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Display display = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                    ? getDisplay()
                    : getWindowManager().getDefaultDisplay();

                if (display != null) {
                    Display.Mode[] modes = display.getSupportedModes();
                    Display.Mode bestMode = null;
                    float maxRefreshRate = 60.0f;

                    for (Display.Mode mode : modes) {
                        if (mode.getRefreshRate() > maxRefreshRate) {
                            maxRefreshRate = mode.getRefreshRate();
                            bestMode = mode;
                        }
                    }

                    WindowManager.LayoutParams params = getWindow().getAttributes();
                    if (bestMode != null) {
                        params.preferredDisplayModeId = bestMode.getModeId();
                    }
                    params.preferredRefreshRate = maxRefreshRate;
                    getWindow().setAttributes(params);
                }
            }
        } catch (Exception ignored) {
            // Fallback safely to system default refresh rate
        }
    }
}
`;

if (fs.existsSync(mainActivityPath)) {
  fs.writeFileSync(mainActivityPath, mainActivityCode, 'utf8');
  console.log('Successfully patched MainActivity.java for 120Hz High Refresh Rate!');
} else {
  console.error('MainActivity.java not found at:', mainActivityPath);
  process.exit(1);
}

const manifestPath = path.join(
  __dirname,
  '..',
  'android',
  'app',
  'src',
  'main',
  'AndroidManifest.xml'
);

if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  if (!manifest.includes('android:hardwareAccelerated="true"')) {
    manifest = manifest.replace(
      '<application',
      '<application android:hardwareAccelerated="true"'
    );
    fs.writeFileSync(manifestPath, manifest, 'utf8');
    console.log('Enabled hardwareAccelerated="true" in AndroidManifest.xml');
  }
}
