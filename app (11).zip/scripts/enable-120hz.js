const fs = require('fs');
const path = require('path');

// 1. Patch MainActivity.java for Native 120Hz
const mainActivityPath = path.join(
  __dirname, '..', 'android', 'app', 'src', 'main', 'java', 'com', 'olmaths', 'amaster', 'MainActivity.java'
);

const mainActivityCode = `package com.olmaths.amaster;

import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.Display;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;
import java.util.Locale;

public class MainActivity extends BridgeActivity {
    private TextToSpeech tts;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enableHighRefreshRate();
        initNativeTTS();
    }

    private void initNativeTTS() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("si", "LK"));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.getDefault());
                }
                tts.setSpeechRate(0.95f);
            }
        });

        if (this.bridge != null && this.bridge.getWebView() != null) {
            this.bridge.getWebView().addJavascriptInterface(new Object() {
                @JavascriptInterface
                public void speak(String text) {
                    if (tts != null) {
                        tts.stop();
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "olmaths_tts");
                    }
                }

                @JavascriptInterface
                public void stop() {
                    if (tts != null) {
                        tts.stop();
                    }
                }
            }, "AndroidTTS");
        }
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    private void enableHighRefreshRate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Display display = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                    ? getDisplay()
                    : getWindowManager().getDefaultDisplay();

                if (display != null) {
                    Display.Mode[] modes = display.getSupportedModes();
                    Display.Mode bestMode = null;
                    float maxRefreshRate = 60.0f;

                    for (Display.Mode mode : modes) {
                        if (mode.getRefreshRate() > maxRefreshRate) {
                            maxRefreshRate = mode.getRefreshRate();
                            bestMode = mode;
                        }
                    }

                    WindowManager.LayoutParams params = getWindow().getAttributes();
                    if (bestMode != null) {
                        params.preferredDisplayModeId = bestMode.getModeId();
                    }
                    params.preferredRefreshRate = maxRefreshRate;
                    getWindow().setAttributes(params);
                }
            }
        } catch (Exception ignored) {}
    }
}
`;

if (fs.existsSync(mainActivityPath)) {
  fs.writeFileSync(mainActivityPath, mainActivityCode, 'utf8');
  console.log('Patched MainActivity.java for 120Hz!');
}

// 2. Enable Hardware Acceleration in AndroidManifest.xml
const manifestPath = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (fs.existsSync(manifestPath)) {
  let manifest = fs.readFileSync(manifestPath, 'utf8');
  if (!manifest.includes('android:hardwareAccelerated="true"')) {
    manifest = manifest.replace('<application', '<application android:hardwareAccelerated="true"');
    fs.writeFileSync(manifestPath, manifest, 'utf8');
  }
}

// 3. Install Custom App Icon (FORCE CLEAN .webp / adaptive XMLs so Android MUST show our A+ icon)
const customIconSrc = path.join(__dirname, '..', 'assets', 'icon.png');
const resDir = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'res');

if (fs.existsSync(customIconSrc) && fs.existsSync(resDir)) {
  // Remove all adaptive icon xml folders (v26, v33, etc.)
  for (const entry of fs.readdirSync(resDir)) {
    if (entry.startsWith('mipmap-anydpi')) {
      fs.rmSync(path.join(resDir, entry), { recursive: true, force: true });
      console.log('Removed adaptive folder:', entry);
    }
  }

  const mipmaps = ['mipmap-mdpi', 'mipmap-hdpi', 'mipmap-xhdpi', 'mipmap-xxhdpi', 'mipmap-xxxhdpi'];
  for (const folder of mipmaps) {
    const dirPath = path.join(resDir, folder);
    fs.mkdirSync(dirPath, { recursive: true });
    // Delete any existing ic_launcher* (.webp, .png, .xml) to prevent conflicts
    for (const f of fs.readdirSync(dirPath)) {
      if (f.startsWith('ic_launcher')) {
        fs.unlinkSync(path.join(dirPath, f));
      }
    }
    fs.copyFileSync(customIconSrc, path.join(dirPath, 'ic_launcher.png'));
    fs.copyFileSync(customIconSrc, path.join(dirPath, 'ic_launcher_round.png'));
  }
  console.log('Successfully installed custom Neon A+ App Icon across all mipmaps!');
} else {
  console.error('WARNING: Custom icon source not found at', customIconSrc);
}
